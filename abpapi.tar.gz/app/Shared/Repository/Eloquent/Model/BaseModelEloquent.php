<?php

namespace App\Shared\Repository\Eloquent\Model;

use Illuminate\Database\Eloquent\Model;

abstract class BaseModelEloquent extends Model
{      
}