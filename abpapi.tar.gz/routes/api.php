<?php

use App\Http\Controllers\AuthController;
use App\Modules\Stock\Brand\Controller\BrandController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
  return $request->user();
});

/**
 * Auth
 */
Route::group(
  [], 
  function () {
    Route::post("register",  [AuthController::class, 'register'])->name("auth-controller.register");
    Route::post("login",  [AuthController::class, 'login'])->name("auth-controller.login");
  }
);

Route::group(
  ['middleware' => ['auth:sanctum']], 
  function () {
    Route::get("user",  [AuthController::class, 'user'])->name("auth-controller.user");
    Route::post("logout",  [AuthController::class, 'logout'])->name("auth-controller.logout");
  }
);


/**
 * Brand (Marca)
 */
Route::group(
  ['prefix' => 'stock', 'middleware' => ['auth:sanctum']],
  function () {
    Route::post("brand/index",  [BrandController::class, 'index'])->name("stock-brand.index");
    Route::post("brand",        [BrandController::class, 'store'])->name("stock-brand.store");
    Route::get("brand/{id}",    [BrandController::class, 'show'])->name("stock-brand.show");
    Route::put("brand/{id}",    [BrandController::class, 'update'])->name("stock-brand.update");
    Route::delete("brand/{id}", [BrandController::class, 'destroy'])->name("stock-brand.destroy");  
  }
);
